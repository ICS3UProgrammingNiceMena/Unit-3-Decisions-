﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PassByRefNiceM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        private void btnRound_Click(object sender, EventArgs e)
        {
            // declare variables
            double userNumber;
            int decimalPlaces;

            // convert th input decimal places from a ting to an int
            decimalPlaces = Convert.ToInt16(nudDecimalPlaces.Value);
            userNumber = Convert.ToDouble(txtUserNumber);

        }
        

        public void PassByRefNiceM (ref double userNumber, int decimalPlaces)
        {
             userNumber = userNumber *Math.Pow(10, userNumber);
             userNumber = userNumber + 0.5;
             userNumber = Math.Truncate(userNumber);
             userNumber = userNumber / Math.Pow(10, userNumber);

            MessageBox.Show(" The rounded number is " + "userNumber ");
        }
          
    }
}