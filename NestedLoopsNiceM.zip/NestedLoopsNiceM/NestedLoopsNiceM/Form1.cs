﻿/*
 * Created by: First Last
 * Created on: Day-Month-Year
 * Created for: ICS3U Programming
 * Daily Assignment – Day #28 - Numbers Nested Loops
 * This program...
*/
namespace NestedLoopsNiceM
{
    public partial class frmNestedLoops : Form
    {
        public object A { get; private set; }

        public frmNestedLoops()
        {
            InitializeComponent();
            // declaring the local variables
            String capitalLetters;
            int secondNumber; 
        }

        private void frmNestedLoops_Load(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // clear the listbox
            this.lstLetters.Items.Clear();

            // covert the letters string
            capitalLetters = .Convert.ToString;


            // loop through letters A to Z
            for (capitalLetters = A; char(capitalLetters <= 10; capitalLeters++) ;
        }
    }
}
